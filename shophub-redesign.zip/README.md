# ShopHub — UI Redesign

ShopHub telah dirombak besar-besaran mengikuti referensi UI yang diberikan: header e-commerce modern, hero/banner promo, kategori populer, flash sale, katalog/sidebar kategori, keranjang, checkout, login modal, dan dashboard admin.

Backend Node.js + Express dan API order tetap dipertahankan. Data produk sekarang juga memiliki aset SVG lokal di `public/assets/products/` agar tampilan kartu produk konsisten tanpa bergantung pada CDN gambar.

## Jalankan

```bash
npm install
npm start
```

Buka `http://localhost:3000`.

- `#home` — homepage
- `#catalog` — halaman katalog
- `#cart` — keranjang
- `#admin` — dashboard admin
